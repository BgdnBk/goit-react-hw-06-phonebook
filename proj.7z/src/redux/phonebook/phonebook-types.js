export default {
  ADD: "phonebook/add",
  DELETE: "phonebook/delete",
  FILTER: "phonebook/changeFilter",
};
