import React from "react";
import s from "../ContactForm/ContactForm.module.css";

function Title() {
  return (
    <div>
      <h1 className={s.form}>Телефонная книга</h1>
    </div>
  );
}

export default Title;
